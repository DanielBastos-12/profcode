class Funcionario():
    porcentagem_aumento = 1.04
   
    def __init__(self, nome, sobrenome, salario):
        self.nome = nome
        self.sobrenome = sobrenome
        self.salario = salario
        self.email = f"{nome.lower()}.{sobrenome.lower()}@empresa.com"

    def nome_completo(self):
        return f"{self.nome} {self.sobrenome}"
    
    def aplicar_aumento(self):
        self.salario = int(self.salario * self.porcentagem_aumento)

    def __repr__(self):
        return "Funcionario('{}','{}',{})".format(self.nome, self.sobrenome, self.salario)
    #Retorna uma representação "oficial" do objeto, que idealmente deveria ser uma string que,
    #se avaliada, pudesse recriar o objeto. É usada principalmente para desenvolvedores.

    def __str__(self):
        return '{} - {}'.format(self.nome_completo(), self.email)
    # Retorna uma representação em string "legível" do objeto, usada principalmente para exibição para o usuário.
    # Quando você usa print() em um objeto, este é o método chamado.

#ESSES MÉTODOS ACIMA SÃO CONHECIDOS COMO MÉTODOS DUNDER

func_1 = Funcionario("João", "Silva", 5000)
func_2 = Funcionario("Maria", "Oliveira", 6000)

print(func_1)
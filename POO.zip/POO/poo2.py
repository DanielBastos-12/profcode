class Funcionario:
    porcentagem_aumento = 1.04
    numero_funcionarios = 0
   
    def __init__(self, nome, sobrenome, salario):
        self.nome = nome
        self.sobrenome = sobrenome
        self.salario = salario
        self.email = f"{nome.lower()}.{sobrenome.lower()}@empresa.com"
        Funcionario.numero_funcionarios += 1

    def nome_completo(self):
        return f"{self.nome} {self.sobrenome}"
    
    def aplicar_aumento(self):
        self.salario = int(self.salario * self.porcentagem_aumento)

    @classmethod
    def definir_porcentagem_aumento(cls, nova_porcentagem):
        cls.porcentagem_aumento = nova_porcentagem
    # O decorator @classmethod indica que este método é um método de classe.
    # Isso significa que ele recebe a própria classe como primeiro argumento, em vez de uma instância da classe.
    # O nome convencional para esse primeiro argumento é cls (abreviação de class).
    # Dentro do método, podemos acessar e modificar atributos de classe usando cls.

    @staticmethod
    def dia_util(dia):
        if dia.weekday() == 5 or dia.weekday() == 6:
            return False
        return True
    # O decorator @staticmethod indica que este método é um método estático.
    # Isso significa que ele não recebe automaticamente a instância (self) ou a classe (cls) como primeiro argumento.
    # Métodos estáticos são usados quando a funcionalidade do método não depende da instância ou da classe.
    
func1 = Funcionario("João", "Silva", 5000)
func2 = Funcionario("Maria", "Oliveira", 6000)
print(f"Total de {Funcionario.numero_funcionarios} funcionários criados.")

print(f"O funcionário {func1.nome_completo()} tem  o salário de {func1.salario}")
func1.aplicar_aumento()
print(f"Após o aumento, o salário de {func1.nome_completo()} é de {func1.salario}")

Funcionario.definir_porcentagem_aumento(1.50)
print(f"A nova porcentagem de aumento é de {Funcionario.porcentagem_aumento}")

import datetime
data = datetime.date(2024, 6, 15)
print(f"O dia {data} é um dia útil? {Funcionario.dia_util(data)}")






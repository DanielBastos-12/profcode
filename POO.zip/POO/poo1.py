class Funcionario:
    porcentagem_aumento = 1.04
    numero_funcionarios = 0
   
    def __init__(self, nome, sobrenome, salario):
     # O __init__ é um método especial que é chamado automaticamente quando você cria um novo objeto da classe.
        # Ele é usado para inicializar os atributos do objeto.
        self.nome = nome
        self.sobrenome = sobrenome
        self.salario = salario
        self.email = f"{nome.lower()}.{sobrenome.lower()}@empresa.com"
    # O self é uma referência ao próprio objeto que está sendo criado.
    # É como se ele estivesse fazendo o seguinte script:
    # func1.nome = "João"
    # func1.sobrenome = "Silva"
    # Quando utilizamos self, estamos dizendo que esses atributos pertencem ao objeto específico que está sendo criado.
        Funcionario.numero_funcionarios += 1

    def nome_completo(self):
        return f"{self.nome} {self.sobrenome}"
    
    def aplicar_aumento(self):
        self.salario = int(self.salario * self.porcentagem_aumento)
    
func1 = Funcionario("João", "Silva", 5000)
func2 = Funcionario("Maria", "Oliveira", 6000)
print(f"Total de {Funcionario.numero_funcionarios} funcionários criados.")

print(f"O funcionário {func1.nome_completo()} tem  o salário de {func1.salario}")
func1.aplicar_aumento()
print(f"Após o aumento, o salário de {func1.nome_completo()} é de {func1.salario}")







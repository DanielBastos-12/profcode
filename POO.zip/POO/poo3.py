class Funcionario:
    porcentagem_aumento = 1.04
   
    def __init__(self, nome, sobrenome, salario):
        self.nome = nome
        self.sobrenome = sobrenome
        self.salario = salario
        self.email = f"{nome.lower()}.{sobrenome.lower()}@empresa.com"

    def nome_completo(self):
        return f"{self.nome} {self.sobrenome}"
    
    def aplicar_aumento(self):
        self.salario = int(self.salario * self.porcentagem_aumento)


class Desenvolvedor(Funcionario):
    porcentagem_aumento = 1.10
    
    def __init__(self, nome, sobrenome, salario, lin_prog):
        super().__init__(nome, sobrenome, salario)
        self.lin_prog = lin_prog

class Gerente(Funcionario):

    def __init__(self, nome, sobrenome, salario, funcionarios=None):
        super().__init__(nome, sobrenome, salario)
        if funcionarios is None:
            self.funcionarios = []
        else:
            self.funcionarios = funcionarios

    def add_func(self, func):
        if func not in self.funcionarios:
            self.funcionarios.append(func)

    def del_func(self, func):
        if func in self.funcionarios:
            self.funcionarios.remove(func)

    def print_func(self):
        for func in self.funcionarios:
            print(func.nome_completo())

    
dev1 = Desenvolvedor("João", "Silva", 5000,"Python")
dev2 = Desenvolvedor("Maria", "Oliveira", 6000, "Java")

print(dev1.email)
print(dev1.lin_prog)


gerente_1 = Gerente("Algum","Chefe", 15000, [dev1])
print(gerente_1.email)

gerente_1.add_func(dev2)
gerente_1.del_func(dev1)

gerente_1.print_func()






